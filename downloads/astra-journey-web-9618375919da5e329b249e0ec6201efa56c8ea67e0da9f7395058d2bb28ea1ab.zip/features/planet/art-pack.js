import { assetURL } from "../../core/assets.js";
// Original pixel pack files; logical scene IDs remain stable for saved sectors.
export const PACK_REVISION = "26e609a73c10";
const rawPaths = {
  "atlas": "/planet-pixelart-v1/characters/compatibility-atlases/player_suit_7x8_896x1024.png?v=26e609a73c10",
  "atlas_casual": "/planet-pixelart-v1/characters/compatibility-atlases/player_casual_7x8_896x1024.png?v=26e609a73c10",
  "landing": "/planet-pixelart-v1/assets/landing_module.png?v=26e609a73c10",
  "landing_pad": "/planet-pixelart-v1/landing/landing_pad.png?v=26e609a73c10",
  "tree_old": "/planet-pixelart-v1/assets/tree_purple_large.png?v=26e609a73c10",
  "tree_young": "/planet-pixelart-v1/assets/tree_green_medium.png?v=26e609a73c10",
  "bush_sparse": "/planet-pixelart-v1/assets/shrub_lilac.png?v=26e609a73c10",
  "grass_tuft": "/planet-pixelart-v1/assets/shrub_lilac.png?v=26e609a73c10",
  "grass_dry": "/planet-pixelart-v1/nature/decorations/fallen_leaves.png?v=26e609a73c10",
  "rock_flat": "/planet-pixelart-v1/nature/rocks/flat_stone.png?v=26e609a73c10",
  "rock_large_cracked": "/planet-pixelart-v1/nature/rocks/large_boulder.png?v=26e609a73c10",
  "water_deep": "/planet-pixelart-v1/water/deep/deep.png?v=26e609a73c10",
  "water_shallow": "/planet-pixelart-v1/water/shallow/shallow.png?v=26e609a73c10",
  "shore_wet": "/planet-pixelart-v1/terrain/sand/sand.png?v=26e609a73c10",
  "move_target": "/planet-pixelart-v1/effects/movement_marker.png?v=26e609a73c10",
  "move_blocked": "/planet-pixelart-v1/effects/blocked_point_marker.png?v=26e609a73c10",
  "selection_ring": "/planet-pixelart-v1/effects/hover_highlight.png?v=26e609a73c10",
  "sector_boundary": "/planet-pixelart-v1/effects/sector_boundary.png?v=26e609a73c10",
  "hover_highlight": "/planet-pixelart-v1/effects/hover_highlight.png?v=26e609a73c10",
  "footstep_dust": "/planet-pixelart-v1/effects/footstep_dust.png?v=26e609a73c10",
  "ground_grass": "/planet-pixelart-v1/terrain/grass/grass.png?v=26e609a73c10",
  "ground_dry": "/planet-pixelart-v1/terrain/dirt/dry_soil.png?v=26e609a73c10",
  "ground_sand": "/planet-pixelart-v1/terrain/sand/sand.png?v=26e609a73c10",
  "ground_rock": "/planet-pixelart-v1/terrain/rock/rocky_ground.png?v=26e609a73c10",
  "ground_snow": "/planet-pixelart-v1/terrain/snow/snow.png?v=26e609a73c10",
  "ground_volcanic": "/planet-pixelart-v1/terrain/volcanic/volcanic.png?v=26e609a73c10",
  "ripple_0": "/planet-pixelart-v1/water/animations/ripple_00.png?v=26e609a73c10",
  "ripple_1": "/planet-pixelart-v1/water/animations/ripple_01.png?v=26e609a73c10",
  "ripple_2": "/planet-pixelart-v1/water/animations/ripple_02.png?v=26e609a73c10",
  "ripple_3": "/planet-pixelart-v1/water/animations/ripple_03.png?v=26e609a73c10"
};

export const ART_PATHS = new Proxy(rawPaths, {
 get(target, key, receiver) { const value = Reflect.get(target, key, receiver); return typeof value === "string" ? assetURL(value) : value; }
});
